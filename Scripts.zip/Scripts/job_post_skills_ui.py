#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import tkinter as tk
from tkinter import ttk
import MySQLdb as mysql
def main():
    # Initialize the MySQL database connection
    db_connection = mysql.connect(
        host="127.0.0.1",
        user="root",
        passwd="root",
        db="jobApplicationPortal"
    )

    # Create a cursor to interact with the database
    db_cursor = db_connection.cursor()

    # Create the main application window
    app = tk.Tk()
    app.title("Job Post Skills Management")

    # Function to add a new job post skill
    def add_job_post_skill():
        job_post_id = job_post_id_entry.get()
        skill_id = skill_id_entry.get()
        skill_level = skill_level_entry.get()
        
        # Insert a new job post skill into the Job_Post_Skills table
        db_cursor.execute(
            "INSERT INTO Job_Post_Skills (JobPostID, SkillID, SkillLevel) VALUES (%s, %s, %s)",
            (job_post_id, skill_id, skill_level)
        )
        db_connection.commit()
        
        success_label.config(text="Job Post Skill added successfully!")

    # Function to display job post skills
    def display_job_post_skills():
        job_post_skills_listbox.delete(0, tk.END)
        db_cursor.execute("SELECT JobPostSkillsID, JobPostID, SkillID, SkillLevel FROM Job_Post_Skills")
        job_post_skills = db_cursor.fetchall()
        for entry in job_post_skills:
            job_post_skills_listbox.insert(tk.END, entry)

    # Create a frame for job post skill information
    job_post_skill_frame = ttk.LabelFrame(app, text="Job Post Skill Information")
    job_post_skill_frame.pack(fill="both", expand="true", padx=10, pady=10)

    job_post_id_label = ttk.Label(job_post_skill_frame, text="Job Post ID:")
    job_post_id_label.grid(row=0, column=0, padx=5, pady=5)

    job_post_id_entry = ttk.Entry(job_post_skill_frame)
    job_post_id_entry.grid(row=0, column=1, padx=5, pady=5)

    skill_id_label = ttk.Label(job_post_skill_frame, text="Skill ID:")
    skill_id_label.grid(row=1, column=0, padx=5, pady=5)

    skill_id_entry = ttk.Entry(job_post_skill_frame)
    skill_id_entry.grid(row=1, column=1, padx=5, pady=5)

    skill_level_label = ttk.Label(job_post_skill_frame, text="Skill Level:")
    skill_level_label.grid(row=2, column=0, padx=5, pady=5)

    skill_level_entry = ttk.Entry(job_post_skill_frame)
    skill_level_entry.grid(row=2, column=1, padx=5, pady=5)

    add_button = ttk.Button(job_post_skill_frame, text="Add Job Post Skill", command=add_job_post_skill)
    add_button.grid(row=3, columnspan=2, padx=5, pady=5)

    # Create a frame to display job post skills
    job_post_skills_list_frame = ttk.LabelFrame(app, text="Job Post Skills List")
    job_post_skills_list_frame.pack(fill="both", expand="true", padx=10, pady=10)

    job_post_skills_listbox = tk.Listbox(job_post_skills_list_frame)
    job_post_skills_listbox.pack(fill="both", expand="true", padx=5, pady=5)

    display_button = ttk.Button(job_post_skills_list_frame, text="Display Job Post Skills", command=display_job_post_skills)
    display_button.pack(padx=5, pady=5)

    # Label to display success messages
    success_label = ttk.Label(app, text="", foreground="green")
    success_label.pack(padx=10, pady=10)

    # Run the application
    app.mainloop()

    # Close the database connection when the application exits
    db_connection.close()
if __name__ == "__main__":
    main()
