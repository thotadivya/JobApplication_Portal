#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import tkinter as tk
from tkinter import ttk
import MySQLdb as mysql
def main():
    # Initialize the MySQL database connection
    db_connection = mysql.connect(
        host="127.0.0.1",
        user="root",
        passwd="root",
        db="jobApplicationPortal"
    )

    # Create a cursor to interact with the database
    db_cursor = db_connection.cursor()

    # Create the main application window
    app = tk.Tk()
    app.title("Applied Job Posts Management")

    # Function to add a new applied job post
    def add_applied_job_post():
        user_id = user_id_entry.get()
        job_post_id = job_post_id_entry.get()
        application_date = application_date_entry.get()
        status = status_entry.get()
        notes = notes_entry.get()
        
        # Insert a new applied job post into the Applied_JobPosts table
        db_cursor.execute(
            "INSERT INTO Applied_JobPosts (UserID, JobPostID, ApplicationDate, Status, Notes) VALUES (%s, %s, %s, %s, %s)",
            (user_id, job_post_id, application_date, status, notes)
        )
        db_connection.commit()
        
        success_label.config(text="Applied Job Post added successfully!")

    # Function to delete the selected applied job post
    def delete_applied_job_post():
        selected_item = applied_job_posts_listbox.curselection()
        if selected_item:
            selected_index = selected_item[0]
            selected_data = applied_job_posts_listbox.get(selected_index)
            application_id = selected_data[0]  # Assuming the first column is the primary key (ApplicationID)
            
            # Delete the selected applied job post from the Applied_JobPosts table
            db_cursor.execute(
                "DELETE FROM Applied_JobPosts WHERE ApplicationID = %s",
                (application_id,)
            )
            db_connection.commit()
            
            success_label.config(text="Applied Job Post deleted successfully!")
        else:
            success_label.config(text="Please select an item to delete.")

    # Function to edit the selected applied job post
    def edit_applied_job_post():
        selected_item = applied_job_posts_listbox.curselection()
        if selected_item:
            selected_index = selected_item[0]
            selected_data = applied_job_posts_listbox.get(selected_index)
            application_id = selected_data[0]  # Assuming the first column is the primary key (ApplicationID)
            
            # Retrieve the existing record from the database
            db_cursor.execute("SELECT * FROM Applied_JobPosts WHERE ApplicationID = %s", (application_id,))
            existing_record = db_cursor.fetchone()
            
            # Update the entry fields with the existing record data
            user_id_entry.delete(0, tk.END)
            user_id_entry.insert(0, existing_record[1])  # Assuming UserID is the second column
            job_post_id_entry.delete(0, tk.END)
            job_post_id_entry.insert(0, existing_record[2])  # Assuming JobPostID is the third column
            application_date_entry.delete(0, tk.END)
            application_date_entry.insert(0, existing_record[3])  # Assuming ApplicationDate is the fourth column
            status_entry.delete(0, tk.END)
            status_entry.insert(0, existing_record[4])  # Assuming Status is the fifth column
            notes_entry.delete(0, tk.END)
            notes_entry.insert(0, existing_record[5])  # Assuming Notes is the sixth column
            
            success_label.config(text="Edit mode: Modify the fields and click 'Update'.")

    # Function to update the edited applied job post
    def update_applied_job_post():
        user_id = user_id_entry.get()
        job_post_id = job_post_id_entry.get()
        application_date = application_date_entry.get()
        status = status_entry.get()
        notes = notes_entry.get()
        
        selected_item = applied_job_posts_listbox.curselection()
        if selected_item:
            selected_index = selected_item[0]
            selected_data = applied_job_posts_listbox.get(selected_index)
            application_id = selected_data[0]  # Assuming the first column is the primary key (ApplicationID)
            
            # Update the selected applied job post in the Applied_JobPosts table
            db_cursor.execute(
                "UPDATE Applied_JobPosts SET UserID = %s, JobPostID = %s, ApplicationDate = %s, Status = %s, Notes = %s WHERE ApplicationID = %s",
                (user_id, job_post_id, application_date, status, notes, application_id)
            )
            db_connection.commit()
            
            success_label.config(text="Applied Job Post updated successfully!")
        else:
            success_label.config(text="Please select an item to edit.")

    # Function to display applied job posts
    def display_applied_job_posts():
        applied_job_posts_listbox.delete(0, tk.END)
        db_cursor.execute("SELECT ApplicationID, UserID, JobPostID, ApplicationDate, Status, Notes FROM Applied_JobPosts")
        applied_job_posts = db_cursor.fetchall()
        for applied_job_post in applied_job_posts:
            applied_job_posts_listbox.insert(tk.END, applied_job_post)

    # Create a frame for applied job post information
    applied_job_posts_frame = ttk.LabelFrame(app, text="Applied Job Post Information")
    applied_job_posts_frame.pack(fill="both", expand="true", padx=10, pady=10)

    user_id_label = ttk.Label(applied_job_posts_frame, text="User ID:")
    user_id_label.grid(row=0, column=0, padx=5, pady=5)

    user_id_entry = ttk.Entry(applied_job_posts_frame)
    user_id_entry.grid(row=0, column=1, padx=5, pady=5)

    job_post_id_label = ttk.Label(applied_job_posts_frame, text="Job Post ID:")
    job_post_id_label.grid(row=1, column=0, padx=5, pady=5)

    job_post_id_entry = ttk.Entry(applied_job_posts_frame)
    job_post_id_entry.grid(row=1, column=1, padx=5, pady=5)

    application_date_label = ttk.Label(applied_job_posts_frame, text="Application Date:")
    application_date_label.grid(row=2, column=0, padx=5, pady=5)

    application_date_entry = ttk.Entry(applied_job_posts_frame)
    application_date_entry.grid(row=2, column=1, padx=5, pady=5)

    status_label = ttk.Label(applied_job_posts_frame, text="Status:")
    status_label.grid(row=3, column=0, padx=5, pady=5)

    status_entry = ttk.Entry(applied_job_posts_frame)
    status_entry.grid(row=3, column=1, padx=5, pady=5)

    notes_label = ttk.Label(applied_job_posts_frame, text="Notes:")
    notes_label.grid(row=4, column=0, padx=5, pady=5)

    notes_entry = ttk.Entry(applied_job_posts_frame)
    notes_entry.grid(row=4, column=1, padx=5, pady=5)

    add_button = ttk.Button(applied_job_posts_frame, text="Add Applied Job Post", command=add_applied_job_post)
    add_button.grid(row=5, columnspan=2, padx=5, pady=5)

    edit_button = ttk.Button(applied_job_posts_frame, text="Edit Selected", command=edit_applied_job_post)
    edit_button.grid(row=6, columnspan=2, padx=5, pady=5)

    update_button = ttk.Button(applied_job_posts_frame, text="Update", command=update_applied_job_post)
    update_button.grid(row=7, columnspan=2, padx=5, pady=5)

    # Label to display success messages
    success_label = ttk.Label(app, text="", foreground="green")
    success_label.pack(padx=10, pady=10)

    # Create a frame to display applied job posts
    applied_job_posts_list_frame = ttk.LabelFrame(app, text="Applied Job Post List")
    applied_job_posts_list_frame.pack(fill="both", expand="true", padx=10, pady=10)

    applied_job_posts_listbox = tk.Listbox(applied_job_posts_list_frame)
    applied_job_posts_listbox.pack(fill="both", expand="true", padx=5, pady=5)

    delete_button = ttk.Button(applied_job_posts_list_frame, text="Delete Selected", command=delete_applied_job_post)
    delete_button.pack(side="left", padx=5, pady=5)

    display_button = ttk.Button(applied_job_posts_list_frame, text="Display Applied Job Posts", command=display_applied_job_posts)
    display_button.pack(side="right", padx=5, pady=5)

    # Run the application
    app.mainloop()

    # Close the database connection when the application exits
    db_connection.close()
if __name__ == "__main__":
    main()
