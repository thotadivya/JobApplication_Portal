#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import tkinter as tk
from tkinter import ttk
import MySQLdb as mysql
from tkinter import messagebox
def main():
    # Initialize the MySQL database connection
    db_connection = mysql.connect(
        host="127.0.0.1",
        user="root",
        passwd="root",
        db="jobApplicationPortal"
    )

    # Create a cursor to interact with the database
    db_cursor = db_connection.cursor()

    # Create the main application window
    app = tk.Tk()
    app.title("User Management")

    # Function to add a new user
    def add_user():
        user_id = user_id_entry.get()
        first_name = first_name_entry.get()
        last_name = last_name_entry.get()
        email = email_entry.get()
        
        # Insert a new user into the Users table
        db_cursor.execute(
            "INSERT INTO Users (UserID, FirstName, LastName, Email) VALUES (%s, %s, %s, %s)",
            (user_id, first_name, last_name, email)
        )
        db_connection.commit()
        
        success_label.config(text="User added successfully!")
        display_users()

    # Function to display user information
    def display_users():
        user_listbox.delete(0, tk.END)
        db_cursor.execute("SELECT UserID, FirstName, LastName, Email FROM Users")
        users = db_cursor.fetchall()
        for user in users:
            user_listbox.insert(tk.END, user)

    # Function to edit the selected user
    def edit_user():
        selected_item = user_listbox.curselection()
        if selected_item:
            selected_index = selected_item[0]
            selected_data = user_listbox.get(selected_index)
            user_id = selected_data[0]  # Assuming the first column is the primary key (UserID)

            # Create a new window for editing
            edit_window = tk.Toplevel(app)
            edit_window.title("Edit User")

            # Labels and Entry widgets for input
            edit_first_name_label = ttk.Label(edit_window, text="First Name:")
            edit_first_name_label.grid(row=0, column=0, padx=5, pady=5)

            edit_first_name_entry = ttk.Entry(edit_window)
            edit_first_name_entry.grid(row=0, column=1, padx=5, pady=5)
            edit_first_name_entry.insert(0, selected_data[1])  # Pre-fill with existing First Name

            edit_last_name_label = ttk.Label(edit_window, text="Last Name:")
            edit_last_name_label.grid(row=1, column=0, padx=5, pady=5)

            edit_last_name_entry = ttk.Entry(edit_window)
            edit_last_name_entry.grid(row=1, column=1, padx=5, pady=5)
            edit_last_name_entry.insert(0, selected_data[2])  # Pre-fill with existing Last Name

            edit_email_label = ttk.Label(edit_window, text="Email:")
            edit_email_label.grid(row=2, column=0, padx=5, pady=5)

            edit_email_entry = ttk.Entry(edit_window)
            edit_email_entry.grid(row=2, column=1, padx=5, pady=5)
            edit_email_entry.insert(0, selected_data[3])  # Pre-fill with existing Email

            # Function to update the user
            def update_user():
                new_first_name = edit_first_name_entry.get()
                new_last_name = edit_last_name_entry.get()
                new_email = edit_email_entry.get()

                # Update the selected user in the Users table
                db_cursor.execute(
                    "UPDATE Users SET FirstName = %s, LastName = %s, Email = %s WHERE UserID = %s",
                    (new_first_name, new_last_name, new_email, user_id)
                )
                db_connection.commit()

                success_label.config(text="User updated successfully!")
                display_users()
                edit_window.destroy()

            # Button to update the user
            update_button = ttk.Button(edit_window, text="Update User", command=update_user)
            update_button.grid(row=3, columnspan=2, padx=5, pady=5)

        else:
            messagebox.showinfo("Information", "Please select a user to edit.")

    # Function to delete the selected user
    def delete_user():
        selected_item = user_listbox.curselection()
        if selected_item:
            selected_index = selected_item[0]
            selected_data = user_listbox.get(selected_index)
            user_id = selected_data[0]  # Assuming the first column is the primary key (UserID)
            
            # Delete the selected user from the Users table
            db_cursor.execute(
                "DELETE FROM Users WHERE UserID = %s",
                (user_id,)
            )
            db_connection.commit()
            
            success_label.config(text="User deleted successfully!")
            display_users()
        else:
            messagebox.showinfo("Information", "Please select a user to delete.")

    # Create a frame for user information
    user_frame = ttk.LabelFrame(app, text="User Information")
    user_frame.pack(fill="both", expand="true", padx=10, pady=10)

    user_id_label = ttk.Label(user_frame, text="User ID:")
    user_id_label.grid(row=0, column=0, padx=5, pady=5)

    user_id_entry = ttk.Entry(user_frame)
    user_id_entry.grid(row=0, column=1, padx=5, pady=5)

    first_name_label = ttk.Label(user_frame, text="First Name:")
    first_name_label.grid(row=1, column=0, padx=5, pady=5)

    first_name_entry = ttk.Entry(user_frame)
    first_name_entry.grid(row=1, column=1, padx=5, pady=5)

    last_name_label = ttk.Label(user_frame, text="Last Name:")
    last_name_label.grid(row=2, column=0, padx=5, pady=5)

    last_name_entry = ttk.Entry(user_frame)
    last_name_entry.grid(row=2, column=1, padx=5, pady=5)

    email_label = ttk.Label(user_frame, text="Email:")
    email_label.grid(row=3, column=0, padx=5, pady=5)

    email_entry = ttk.Entry(user_frame)
    email_entry.grid(row=3, column=1, padx=5, pady=5)

    add_button = ttk.Button(user_frame, text="Add User", command=add_user)
    add_button.grid(row=4, columnspan=2, padx=5, pady=5)

    # Create Edit and Delete Buttons
    edit_button = ttk.Button(user_frame, text="Edit User", command=edit_user)
    edit_button.grid(row=5, column=0, padx=5, pady=5)

    delete_button = ttk.Button(user_frame, text="Delete User", command=delete_user)
    delete_button.grid(row=5, column=1, padx=5, pady=5)

    # Create a frame to display user information
    user_list_frame = ttk.LabelFrame(app, text="User List")
    user_list_frame.pack(fill="both", expand="true", padx=10, pady=10)

    user_listbox = tk.Listbox(user_list_frame)
    user_listbox.pack(fill="both", expand="true", padx=5, pady=5)

    display_button = ttk.Button(user_list_frame, text="Display Users", command=display_users)
    display_button.pack(padx=5, pady=5)

    # Label to display success messages
    success_label = ttk.Label(app, text="", foreground="green")
    success_label.pack(padx=10, pady=10)

    # Run the application
    app.mainloop()

    # Close the database connection when the application exits
    db_connection.close()
if __name__ == "__main__":
    main()
