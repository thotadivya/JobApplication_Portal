#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import tkinter as tk
from tkinter import ttk
import MySQLdb as mysql
def main():
    # Initialize the MySQL database connection
    db_connection = mysql.connect(
        host="127.0.0.1",
        user="root",
        passwd="root",
        db="jobApplicationPortal"
    )

    # Create a cursor to interact with the database
    db_cursor = db_connection.cursor()

    # Create the main application window
    app = tk.Tk()
    app.title("Company Management")

    # Function to add a new company
    def add_company():
        company_id = company_id_entry.get()
        company_name = company_name_entry.get()
        industry_id = industry_id_entry.get()
        
        # Insert a new company into the Company table
        db_cursor.execute(
            "INSERT INTO Company (CompanyID, Name, IndustryID) VALUES (%s, %s, %s)",
            (company_id, company_name, industry_id)
        )
        db_connection.commit()
        
        success_label.config(text="Company added successfully!")

    # Function to display company information
    def display_companies():
        company_listbox.delete(0, tk.END)
        db_cursor.execute("SELECT CompanyID, Name, IndustryID FROM Company")
        companies = db_cursor.fetchall()
        for company in companies:
            company_listbox.insert(tk.END, company)

    # Create a frame for company information
    company_frame = ttk.LabelFrame(app, text="Company Information")
    company_frame.pack(fill="both", expand="true", padx=10, pady=10)

    company_id_label = ttk.Label(company_frame, text="Company ID:")
    company_id_label.grid(row=0, column=0, padx=5, pady=5)

    company_id_entry = ttk.Entry(company_frame)
    company_id_entry.grid(row=0, column=1, padx=5, pady=5)

    company_name_label = ttk.Label(company_frame, text="Company Name:")
    company_name_label.grid(row=1, column=0, padx=5, pady=5)

    company_name_entry = ttk.Entry(company_frame)
    company_name_entry.grid(row=1, column=1, padx=5, pady=5)

    industry_id_label = ttk.Label(company_frame, text="Industry ID:")
    industry_id_label.grid(row=2, column=0, padx=5, pady=5)

    industry_id_entry = ttk.Entry(company_frame)
    industry_id_entry.grid(row=2, column=1, padx=5, pady=5)

    add_button = ttk.Button(company_frame, text="Add Company", command=add_company)
    add_button.grid(row=3, columnspan=2, padx=5, pady=5)

    # Create a frame to display company information
    company_list_frame = ttk.LabelFrame(app, text="Company List")
    company_list_frame.pack(fill="both", expand="true", padx=10, pady=10)

    company_listbox = tk.Listbox(company_list_frame)
    company_listbox.pack(fill="both", expand="true", padx=5, pady=5)

    display_button = ttk.Button(company_list_frame, text="Display Companies", command=display_companies)
    display_button.pack(padx=5, pady=5)

    # Label to display success messages
    success_label = ttk.Label(app, text="", foreground="green")
    success_label.pack(padx=10, pady=10)

    # Run the application
    app.mainloop()

    # Close the database connection when the application exits
    db_connection.close()
if __name__ == "__main__":
    main()
