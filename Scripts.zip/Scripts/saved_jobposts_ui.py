#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import tkinter as tk
from tkinter import ttk
import MySQLdb as mysql
def main():
    # Initialize the MySQL database connection
    db_connection = mysql.connect(
        host="127.0.0.1",
        user="root",
        passwd="root",
        db="jobApplicationPortal"
    )

    # Create a cursor to interact with the database
    db_cursor = db_connection.cursor()

    # Create the main application window
    app = tk.Tk()
    app.title("Saved Job Posts Management")

    # Function to add a new saved job post
    def add_saved_job_post():
        saved_job_id = saved_job_id_entry.get()
        user_id = user_id_entry.get()
        job_post_id = job_post_id_entry.get()
        save_date = save_date_entry.get()
        
        # Insert a new saved job post into the Saved_JobPosts table
        db_cursor.execute(
            "INSERT INTO Saved_JobPosts (SavedJobID, UserID, JobPostID, SaveDate) VALUES (%s, %s, %s, %s)",
            (saved_job_id, user_id, job_post_id, save_date)
        )
        db_connection.commit()
        
        success_label.config(text="Saved Job Post added successfully!")

    # Function to display saved job posts
    def display_saved_job_posts():
        saved_job_post_listbox.delete(0, tk.END)
        db_cursor.execute("SELECT SavedJobID, UserID, JobPostID, SaveDate FROM Saved_JobPosts")
        saved_job_posts = db_cursor.fetchall()
        for saved_job_post in saved_job_posts:
            saved_job_post_listbox.insert(tk.END, saved_job_post)

    # Function to delete the selected saved job post
    def delete_saved_job_post():
        selected_item = saved_job_post_listbox.curselection()
        if selected_item:
            selected_index = selected_item[0]
            selected_data = saved_job_post_listbox.get(selected_index)
            saved_job_id = selected_data[0]  # Assuming the first column is the primary key (SavedJobID)
            
            # Delete the selected saved job post from the Saved_JobPosts table
            db_cursor.execute(
                "DELETE FROM Saved_JobPosts WHERE SavedJobID = %s",
                (saved_job_id,)
            )
            db_connection.commit()
            
            success_label.config(text="Saved Job Post deleted successfully!")
            display_saved_job_posts()
        else:
            success_label.config(text="Please select a saved job post to delete.")

    # Create a frame for saved job post information
    saved_job_post_frame = ttk.LabelFrame(app, text="Saved Job Post Information")
    saved_job_post_frame.pack(fill="both", expand="true", padx=10, pady=10)

    saved_job_id_label = ttk.Label(saved_job_post_frame, text="Saved Job ID:")
    saved_job_id_label.grid(row=0, column=0, padx=5, pady=5)

    saved_job_id_entry = ttk.Entry(saved_job_post_frame)
    saved_job_id_entry.grid(row=0, column=1, padx=5, pady=5)

    user_id_label = ttk.Label(saved_job_post_frame, text="User ID:")
    user_id_label.grid(row=1, column=0, padx=5, pady=5)

    user_id_entry = ttk.Entry(saved_job_post_frame)
    user_id_entry.grid(row=1, column=1, padx=5, pady=5)

    job_post_id_label = ttk.Label(saved_job_post_frame, text="Job Post ID:")
    job_post_id_label.grid(row=2, column=0, padx=5, pady=5)

    job_post_id_entry = ttk.Entry(saved_job_post_frame)
    job_post_id_entry.grid(row=2, column=1, padx=5, pady=5)

    save_date_label = ttk.Label(saved_job_post_frame, text="Save Date:")
    save_date_label.grid(row=3, column=0, padx=5, pady=5)

    save_date_entry = ttk.Entry(saved_job_post_frame)
    save_date_entry.grid(row=3, column=1, padx=5, pady=5)

    add_button = ttk.Button(saved_job_post_frame, text="Add Saved Job Post", command=add_saved_job_post)
    add_button.grid(row=4, columnspan=2, padx=5, pady=5)

    # Create Delete Button
    delete_button = ttk.Button(saved_job_post_frame, text="Delete Saved Job Post", command=delete_saved_job_post)
    delete_button.grid(row=5, columnspan=2, padx=5, pady=5)

    # Create a frame to display saved job post information
    saved_job_post_list_frame = ttk.LabelFrame(app, text="Saved Job Post List")
    saved_job_post_list_frame.pack(fill="both", expand="true", padx=10, pady=10)

    saved_job_post_listbox = tk.Listbox(saved_job_post_list_frame)
    saved_job_post_listbox.pack(fill="both", expand="true", padx=5, pady=5)

    display_button = ttk.Button(saved_job_post_list_frame, text="Display Saved Job Posts", command=display_saved_job_posts)
    display_button.pack(padx=5, pady=5)

    # Label to display success messages
    success_label = ttk.Label(app, text="", foreground="green")
    success_label.pack(padx=10, pady=10)

    # Run the application
    app.mainloop()

    # Close the database connection when the application exits
    db_connection.close()
if __name__ == "__main__":
    main()
