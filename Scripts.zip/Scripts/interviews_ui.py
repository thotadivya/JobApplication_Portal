#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import tkinter as tk
from tkinter import ttk
import MySQLdb as mysql
def main():
    # Initialize the MySQL database connection
    db_connection = mysql.connect(
        host="127.0.0.1",
        user="root",
        passwd="root",
        db="jobApplicationPortal"
    )

    # Create a cursor to interact with the database
    db_cursor = db_connection.cursor()

    # Create the main application window
    app = tk.Tk()
    app.title("Interview Management")

    # Function to add a new interview
    def add_interview():
        application_id = application_id_entry.get()
        interview_date = interview_date_entry.get()
        interview_type = interview_type_entry.get()
        interview_notes = interview_notes_entry.get()
        
        # Insert a new interview into the Interviews table
        db_cursor.execute(
            "INSERT INTO Interviews (ApplicationID, InterviewDate, InterviewType, InterviewNotes) VALUES (%s, %s, %s, %s)",
            (application_id, interview_date, interview_type, interview_notes)
        )
        db_connection.commit()
        
        success_label.config(text="Interview added successfully!")

    # Function to display interviews
    def display_interviews():
        interview_listbox.delete(0, tk.END)
        db_cursor.execute("SELECT InterviewID, ApplicationID, InterviewDate, InterviewType, InterviewNotes FROM Interviews")
        interviews = db_cursor.fetchall()
        for interview in interviews:
            interview_listbox.insert(tk.END, interview)

    # Function to delete the selected interview
    def delete_interview():
        selected_item = interview_listbox.curselection()
        if selected_item:
            selected_index = selected_item[0]
            selected_data = interview_listbox.get(selected_index)
            interview_id = selected_data[0]  # Assuming the first column is the primary key (InterviewID)
            
            # Delete the selected interview from the Interviews table
            db_cursor.execute(
                "DELETE FROM Interviews WHERE InterviewID = %s",
                (interview_id,)
            )
            db_connection.commit()
            
            success_label.config(text="Interview deleted successfully!")
        else:
            success_label.config(text="Please select an interview to delete.")

    # Function to edit the selected interview
    def edit_interview():
        selected_item = interview_listbox.curselection()
        if selected_item:
            selected_index = selected_item[0]
            selected_data = interview_listbox.get(selected_index)
            interview_id = selected_data[0]  # Assuming the first column is the primary key (InterviewID)
            
            # Retrieve the existing interview record from the database
            db_cursor.execute("SELECT * FROM Interviews WHERE InterviewID = %s", (interview_id,))
            existing_record = db_cursor.fetchone()
            
            # Update the entry fields with the existing record data
            application_id_entry.delete(0, tk.END)
            application_id_entry.insert(0, existing_record[1])  # Assuming ApplicationID is the second column
            interview_date_entry.delete(0, tk.END)
            interview_date_entry.insert(0, existing_record[2])  # Assuming InterviewDate is the third column
            interview_type_entry.delete(0, tk.END)
            interview_type_entry.insert(0, existing_record[3])  # Assuming InterviewType is the fourth column
            interview_notes_entry.delete(0, tk.END)
            interview_notes_entry.insert(0, existing_record[4])  # Assuming InterviewNotes is the fifth column
            
            success_label.config(text="Edit mode: Modify the fields and click 'Update'.")

    # Function to update the edited interview
    def update_interview():
        application_id = application_id_entry.get()
        interview_date = interview_date_entry.get()
        interview_type = interview_type_entry.get()
        interview_notes = interview_notes_entry.get()
        
        selected_item = interview_listbox.curselection()
        if selected_item:
            selected_index = selected_item[0]
            selected_data = interview_listbox.get(selected_index)
            interview_id = selected_data[0]  # Assuming the first column is the primary key (InterviewID)
            
            # Update the selected interview in the Interviews table
            db_cursor.execute(
                "UPDATE Interviews SET ApplicationID = %s, InterviewDate = %s, InterviewType = %s, InterviewNotes = %s WHERE InterviewID = %s",
                (application_id, interview_date, interview_type, interview_notes, interview_id)
            )
            db_connection.commit()
            
            success_label.config(text="Interview updated successfully!")
        else:
            success_label.config(text="Please select an interview to edit.")

    # Create a frame for interview information
    interview_frame = ttk.LabelFrame(app, text="Interview Information")
    interview_frame.pack(fill="both", expand="true", padx=10, pady=10)

    application_id_label = ttk.Label(interview_frame, text="Application ID:")
    application_id_label.grid(row=0, column=0, padx=5, pady=5)

    application_id_entry = ttk.Entry(interview_frame)
    application_id_entry.grid(row=0, column=1, padx=5, pady=5)

    interview_date_label = ttk.Label(interview_frame, text="Interview Date:")
    interview_date_label.grid(row=1, column=0, padx=5, pady=5)

    interview_date_entry = ttk.Entry(interview_frame)
    interview_date_entry.grid(row=1, column=1, padx=5, pady=5)

    interview_type_label = ttk.Label(interview_frame, text="Interview Type:")
    interview_type_label.grid(row=2, column=0, padx=5, pady=5)

    interview_type_entry = ttk.Entry(interview_frame)
    interview_type_entry.grid(row=2, column=1, padx=5, pady=5)

    interview_notes_label = ttk.Label(interview_frame, text="Interview Notes:")
    interview_notes_label.grid(row=3, column=0, padx=5, pady=5)

    interview_notes_entry = ttk.Entry(interview_frame)
    interview_notes_entry.grid(row=3, column=1, padx=5, pady=5)

    add_button = ttk.Button(interview_frame, text="Add Interview", command=add_interview)
    add_button.grid(row=4, columnspan=2, padx=5, pady=5)

    edit_button = ttk.Button(interview_frame, text="Edit Selected", command=edit_interview)
    edit_button.grid(row=5, columnspan=2, padx=5, pady=5)

    update_button = ttk.Button(interview_frame, text="Update", command=update_interview)
    update_button.grid(row=6, columnspan=2, padx=5, pady=5)

    # Create a frame to display interviews
    interview_list_frame = ttk.LabelFrame(app, text="Interview List")
    interview_list_frame.pack(fill="both", expand="true", padx=10, pady=10)

    interview_listbox = tk.Listbox(interview_list_frame)
    interview_listbox.pack(fill="both", expand="true", padx=5, pady=5)

    delete_button = ttk.Button(interview_list_frame, text="Delete Selected", command=delete_interview)
    delete_button.pack(side="left", padx=5, pady=5)

    display_button = ttk.Button(interview_list_frame, text="Display Interviews", command=display_interviews)
    display_button.pack(side="right", padx=5, pady=5)

    # Label to display success messages
    success_label = ttk.Label(app, text="", foreground="green")
    success_label.pack(padx=10, pady=10)

    # Run the application
    app.mainloop()

    # Close the database connection when the application exits
    db_connection.close()
if __name__ == "__main__":
    main()
