#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import tkinter as tk
from tkinter import ttk
import MySQLdb as mysql
def main():
    # Initialize the MySQL database connection
    db_connection = mysql.connect(
        host="127.0.0.1",
        user="root",
        passwd="root",
        db="jobApplicationPortal"
    )

    # Create a cursor to interact with the database
    db_cursor = db_connection.cursor()

    # Create the main application window
    app = tk.Tk()
    app.title("Districts/Cities Management")

    # Function to add a new district/city
    def add_district_city():
        district_city_id = district_city_id_entry.get()
        state_id = state_id_entry.get()
        district_city_name = district_city_name_entry.get()
        
        # Insert a new district/city into the Districts_or_Cities table
        db_cursor.execute(
            "INSERT INTO Districts_or_Cities (DistrictCityID, StateID, Name) VALUES (%s, %s, %s)",
            (district_city_id, state_id, district_city_name)
        )
        db_connection.commit()
        
        success_label.config(text="District/City added successfully!")
        display_district_cities()

    # Function to display district/city information
    def display_district_cities():
        district_city_listbox.delete(0, tk.END)
        db_cursor.execute("SELECT DistrictCityID, StateID, Name FROM Districts_or_Cities")
        districts_cities = db_cursor.fetchall()
        for district_city in districts_cities:
            district_city_listbox.insert(tk.END, district_city)

    # Function to edit the selected district/city
    def edit_district_city():
        selected_item = district_city_listbox.curselection()
        if selected_item:
            selected_index = selected_item[0]
            selected_data = district_city_listbox.get(selected_index)
            district_city_id = selected_data[0]  # Assuming the first column is the primary key (DistrictCityID)

            # Create a new window for editing
            edit_window = tk.Toplevel(app)
            edit_window.title("Edit District/City")

            # Labels and Entry widgets for input
            edit_district_city_id_label = ttk.Label(edit_window, text="District/City ID:")
            edit_district_city_id_label.grid(row=0, column=0, padx=5, pady=5)

            edit_district_city_id_entry = ttk.Entry(edit_window)
            edit_district_city_id_entry.grid(row=0, column=1, padx=5, pady=5)
            edit_district_city_id_entry.insert(0, selected_data[0])  # Pre-fill with existing DistrictCity ID

            edit_state_id_label = ttk.Label(edit_window, text="State ID:")
            edit_state_id_label.grid(row=1, column=0, padx=5, pady=5)

            edit_state_id_entry = ttk.Entry(edit_window)
            edit_state_id_entry.grid(row=1, column=1, padx=5, pady=5)
            edit_state_id_entry.insert(0, selected_data[1])  # Pre-fill with existing State ID

            edit_district_city_name_label = ttk.Label(edit_window, text="District/City Name:")
            edit_district_city_name_label.grid(row=2, column=0, padx=5, pady=5)

            edit_district_city_name_entry = ttk.Entry(edit_window)
            edit_district_city_name_entry.grid(row=2, column=1, padx=5, pady=5)
            edit_district_city_name_entry.insert(0, selected_data[2])  # Pre-fill with existing Name

            # Function to update the district/city
            def update_district_city():
                new_district_city_id = edit_district_city_id_entry.get()
                new_state_id = edit_state_id_entry.get()
                new_district_city_name = edit_district_city_name_entry.get()

                # Update the selected district/city in the Districts_or_Cities table
                db_cursor.execute(
                    "UPDATE Districts_or_Cities SET DistrictCityID = %s, StateID = %s, Name = %s WHERE DistrictCityID = %s",
                    (new_district_city_id, new_state_id, new_district_city_name, district_city_id)
                )
                db_connection.commit()

                success_label.config(text="District/City updated successfully!")
                display_district_cities()
                edit_window.destroy()

            # Button to update the district/city
            update_button = ttk.Button(edit_window, text="Update District/City", command=update_district_city)
            update_button.grid(row=3, columnspan=2, padx=5, pady=5)

        else:
            success_label.config(text="Please select a district/city to edit.")

    # Function to delete the selected district/city
    def delete_district_city():
        selected_item = district_city_listbox.curselection()
        if selected_item:
            selected_index = selected_item[0]
            selected_data = district_city_listbox.get(selected_index)
            district_city_id = selected_data[0]  # Assuming the first column is the primary key (DistrictCityID)
            
            # Delete the selected district/city from the Districts_or_Cities table
            db_cursor.execute(
                "DELETE FROM Districts_or_Cities WHERE DistrictCityID = %s",
                (district_city_id,)
            )
            db_connection.commit()
            
            success_label.config(text="District/City deleted successfully!")
            display_district_cities()
        else:
            success_label.config(text="Please select a district/city to delete.")

    # Create a frame for district/city information
    district_city_frame = ttk.LabelFrame(app, text="District/City Information")
    district_city_frame.pack(fill="both", expand="true", padx=10, pady=10)

    district_city_id_label = ttk.Label(district_city_frame, text="District/City ID:")
    district_city_id_label.grid(row=0, column=0, padx=5, pady=5)

    district_city_id_entry = ttk.Entry(district_city_frame)
    district_city_id_entry.grid(row=0, column=1, padx=5, pady=5)

    state_id_label = ttk.Label(district_city_frame, text="State ID:")
    state_id_label.grid(row=1, column=0, padx=5, pady=5)

    state_id_entry = ttk.Entry(district_city_frame)
    state_id_entry.grid(row=1, column=1, padx=5, pady=5)

    district_city_name_label = ttk.Label(district_city_frame, text="District/City Name:")
    district_city_name_label.grid(row=2, column=0, padx=5, pady=5)

    district_city_name_entry = ttk.Entry(district_city_frame)
    district_city_name_entry.grid(row=2, column=1, padx=5, pady=5)

    add_button = ttk.Button(district_city_frame, text="Add District/City", command=add_district_city)
    add_button.grid(row=3, columnspan=2, padx=5, pady=5)

    # Create Edit and Delete Buttons
    edit_button = ttk.Button(district_city_frame, text="Edit District/City", command=edit_district_city)
    edit_button.grid(row=4, column=0, padx=5, pady=5)

    delete_button = ttk.Button(district_city_frame, text="Delete District/City", command=delete_district_city)
    delete_button.grid(row=4, column=1, padx=5, pady=5)

    # Create a frame to display district/city information
    district_city_list_frame = ttk.LabelFrame(app, text="District/City List")
    district_city_list_frame.pack(fill="both", expand="true", padx=10, pady=10)

    district_city_listbox = tk.Listbox(district_city_list_frame)
    district_city_listbox.pack(fill="both", expand="true", padx=5, pady=5)

    display_button = ttk.Button(district_city_list_frame, text="Display Districts/Cities", command=display_district_cities)
    display_button.pack(padx=5, pady=5)

    # Label to display success messages
    success_label = ttk.Label(app, text="", foreground="green")
    success_label.pack(padx=10, pady=10)

    # Run the application
    app.mainloop()

    # Close the database connection when the application exits
    db_connection.close()
if __name__ == "__main__":
    main()
