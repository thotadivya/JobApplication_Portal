#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import tkinter as tk
from tkinter import ttk
import MySQLdb as mysql
def main():
    # Initialize the MySQL database connection
    db_connection = mysql.connect(
        host="127.0.0.1",
        user="root",
        passwd="root",
        db="jobApplicationPortal"
    )

    # Create a cursor to interact with the database
    db_cursor = db_connection.cursor()

    # Create the main application window
    app = tk.Tk()
    app.title("States Management")

    # Function to add a new state
    def add_state():
        state_id = state_id_entry.get()
        state_name = state_name_entry.get()
        
        # Insert a new state into the States table
        db_cursor.execute(
            "INSERT INTO States (StateID, Name) VALUES (%s, %s)",
            (state_id, state_name)
        )
        db_connection.commit()
        
        success_label.config(text="State added successfully!")
        display_states()

    # Function to display states
    def display_states():
        state_listbox.delete(0, tk.END)
        db_cursor.execute("SELECT StateID, Name FROM States")
        states = db_cursor.fetchall()
        for state in states:
            state_listbox.insert(tk.END, state)

    # Function to edit the selected state
    def edit_state():
        selected_item = state_listbox.curselection()
        if selected_item:
            selected_index = selected_item[0]
            selected_data = state_listbox.get(selected_index)
            state_id = selected_data[0]  # Assuming the first column is the primary key (StateID)
            
            new_state_name = state_name_entry.get()
            
            # Update the selected state in the States table
            db_cursor.execute(
                "UPDATE States SET Name = %s WHERE StateID = %s",
                (new_state_name, state_id)
            )
            db_connection.commit()
            
            success_label.config(text="State updated successfully!")
            display_states()
        else:
            success_label.config(text="Please select a state to edit.")

    # Function to delete the selected state
    def delete_state():
        selected_item = state_listbox.curselection()
        if selected_item:
            selected_index = selected_item[0]
            selected_data = state_listbox.get(selected_index)
            state_id = selected_data[0]  # Assuming the first column is the primary key (StateID)
            
            # Delete the selected state from the States table
            db_cursor.execute(
                "DELETE FROM States WHERE StateID = %s",
                (state_id,)
            )
            db_connection.commit()
            
            success_label.config(text="State deleted successfully!")
            display_states()
        else:
            success_label.config(text="Please select a state to delete.")

    # Create a frame for state information
    state_frame = ttk.LabelFrame(app, text="State Information")
    state_frame.pack(fill="both", expand="true", padx=10, pady=10)

    state_id_label = ttk.Label(state_frame, text="State ID:")
    state_id_label.grid(row=0, column=0, padx=5, pady=5)

    state_id_entry = ttk.Entry(state_frame)
    state_id_entry.grid(row=0, column=1, padx=5, pady=5)

    state_name_label = ttk.Label(state_frame, text="State Name:")
    state_name_label.grid(row=1, column=0, padx=5, pady=5)

    state_name_entry = ttk.Entry(state_frame)
    state_name_entry.grid(row=1, column=1, padx=5, pady=5)

    add_button = ttk.Button(state_frame, text="Add State", command=add_state)
    add_button.grid(row=2, columnspan=2, padx=5, pady=5)

    # Create Edit and Delete Buttons
    edit_button = ttk.Button(state_frame, text="Edit State", command=edit_state)
    edit_button.grid(row=3, column=0, padx=5, pady=5)

    delete_button = ttk.Button(state_frame, text="Delete State", command=delete_state)
    delete_button.grid(row=3, column=1, padx=5, pady=5)

    # Create a frame to display state information
    state_list_frame = ttk.LabelFrame(app, text="State List")
    state_list_frame.pack(fill="both", expand="true", padx=10, pady=10)

    state_listbox = tk.Listbox(state_list_frame)
    state_listbox.pack(fill="both", expand="true", padx=5, pady=5)

    display_button = ttk.Button(state_list_frame, text="Display States", command=display_states)
    display_button.pack(padx=5, pady=5)

    # Label to display success messages
    success_label = ttk.Label(app, text="", foreground="green")
    success_label.pack(padx=10, pady=10)

    # Run the application
    app.mainloop()

    # Close the database connection when the application exits
    db_connection.close()
if __name__ == "__main__":
    main()
