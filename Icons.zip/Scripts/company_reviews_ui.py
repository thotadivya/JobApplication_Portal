#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import tkinter as tk
from tkinter import ttk
import MySQLdb as mysql
def main():
    # Initialize the MySQL database connection
    db_connection = mysql.connect(
        host="127.0.0.1",
        user="root",
        passwd="root",
        db="jobApplicationPortal"
    )

    # Create a cursor to interact with the database
    db_cursor = db_connection.cursor()

    # Create the main application window
    app = tk.Tk()
    app.title("Company Reviews Management")

    # Function to add a new company review
    def add_company_review():
        review_id = review_id_entry.get()
        company_id = company_id_entry.get()
        user_id = user_id_entry.get()
        rating = rating_entry.get()
        review_text = review_text_entry.get()
        
        # Insert a new company review into the Company_Reviews table
        db_cursor.execute(
            "INSERT INTO Company_Reviews (ReviewID, CompanyID, UserID, Rating, ReviewText) VALUES (%s, %s, %s, %s, %s)",
            (review_id, company_id, user_id, rating, review_text)
        )
        db_connection.commit()
        
        success_label.config(text="Company review added successfully!")
        display_company_reviews()

    # Function to display company reviews
    def display_company_reviews():
        company_reviews_listbox.delete(0, tk.END)
        db_cursor.execute("SELECT ReviewID, CompanyID, UserID, Rating, ReviewText FROM Company_Reviews")
        company_reviews = db_cursor.fetchall()
        for review in company_reviews:
            company_reviews_listbox.insert(tk.END, review)

    # Create a frame for company review information
    company_reviews_frame = ttk.LabelFrame(app, text="Company Review Information")
    company_reviews_frame.pack(fill="both", expand="true", padx=10, pady=10)

    review_id_label = ttk.Label(company_reviews_frame, text="Review ID:")
    review_id_label.grid(row=0, column=0, padx=5, pady=5)

    review_id_entry = ttk.Entry(company_reviews_frame)
    review_id_entry.grid(row=0, column=1, padx=5, pady=5)

    company_id_label = ttk.Label(company_reviews_frame, text="Company ID:")
    company_id_label.grid(row=1, column=0, padx=5, pady=5)

    company_id_entry = ttk.Entry(company_reviews_frame)
    company_id_entry.grid(row=1, column=1, padx=5, pady=5)

    user_id_label = ttk.Label(company_reviews_frame, text="User ID:")
    user_id_label.grid(row=2, column=0, padx=5, pady=5)

    user_id_entry = ttk.Entry(company_reviews_frame)
    user_id_entry.grid(row=2, column=1, padx=5, pady=5)

    rating_label = ttk.Label(company_reviews_frame, text="Rating:")
    rating_label.grid(row=3, column=0, padx=5, pady=5)

    rating_entry = ttk.Entry(company_reviews_frame)
    rating_entry.grid(row=3, column=1, padx=5, pady=5)

    review_text_label = ttk.Label(company_reviews_frame, text="Review Text:")
    review_text_label.grid(row=4, column=0, padx=5, pady=5)

    review_text_entry = ttk.Entry(company_reviews_frame)
    review_text_entry.grid(row=4, column=1, padx=5, pady=5)

    add_button = ttk.Button(company_reviews_frame, text="Add Company Review", command=add_company_review)
    add_button.grid(row=5, columnspan=2, padx=5, pady=5)

    # Create a frame to display company reviews
    company_reviews_list_frame = ttk.LabelFrame(app, text="Company Reviews List")
    company_reviews_list_frame.pack(fill="both", expand="true", padx=10, pady=10)

    company_reviews_listbox = tk.Listbox(company_reviews_list_frame)
    company_reviews_listbox.pack(fill="both", expand="true", padx=5, pady=5)

    display_button = ttk.Button(company_reviews_list_frame, text="Display Company Reviews", command=display_company_reviews)
    display_button.pack(padx=5, pady=5)

    # Label to display success messages
    success_label = ttk.Label(app, text="", foreground="green")
    success_label.pack(padx=10, pady=10)

    # Run the application
    app.mainloop()

    # Close the database connection when the application exits
    db_connection.close()
if __name__ == "__main__":
    main()
