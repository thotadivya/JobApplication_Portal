#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import tkinter as tk
from tkinter import ttk
import MySQLdb as mysql
def main():
    # Initialize the MySQL database connection
    db_connection = mysql.connect(
        host="127.0.0.1",
        user="root",
        passwd="root",
        db="jobApplicationPortal"
    )

    # Create a cursor to interact with the database
    db_cursor = db_connection.cursor()

    # Create the main application window
    app = tk.Tk()
    app.title("Job Post Management")

    # Function to add a new job post
    def add_job_post():
        job_post_id = job_post_id_entry.get()
        company_id = company_id_entry.get()
        job_title = job_title_entry.get()
        
        # Insert a new job post into the Job_Post table
        db_cursor.execute(
            "INSERT INTO Job_Post (JobPostID, CompanyID, JobTitle) VALUES (%s, %s, %s)",
            (job_post_id, company_id, job_title,)
        )
        db_connection.commit()
        
        success_label.config(text="Job Post added successfully!")

    # Function to display job posts
    def display_job_posts():
        job_post_listbox.delete(0, tk.END)
        db_cursor.execute("SELECT JobPostID, CompanyID, JobTitle FROM Job_Post")
        job_posts = db_cursor.fetchall()
        for job_post in job_posts:
            job_post_listbox.insert(tk.END, job_post)

    # Create a frame for job post information
    job_post_frame = ttk.LabelFrame(app, text="Job Post Information")
    job_post_frame.pack(fill="both", expand="true", padx=10, pady=10)

    job_post_id_label = ttk.Label(job_post_frame, text="Job Post ID:")
    job_post_id_label.grid(row=0, column=0, padx=5, pady=5)

    job_post_id_entry = ttk.Entry(job_post_frame)
    job_post_id_entry.grid(row=0, column=1, padx=5, pady=5)

    company_id_label = ttk.Label(job_post_frame, text="Company ID:")
    company_id_label.grid(row=1, column=0, padx=5, pady=5)

    company_id_entry = ttk.Entry(job_post_frame)
    company_id_entry.grid(row=1, column=1, padx=5, pady=5)

    job_title_label = ttk.Label(job_post_frame, text="Job Title:")
    job_title_label.grid(row=2, column=0, padx=5, pady=5)

    job_title_entry = ttk.Entry(job_post_frame)
    job_title_entry.grid(row=2, column=1, padx=5, pady=5)

    add_button = ttk.Button(job_post_frame, text="Add Job Post", command=add_job_post)
    add_button.grid(row=3, columnspan=2, padx=5, pady=5)

    # Create a frame to display job post information
    job_post_list_frame = ttk.LabelFrame(app, text="Job Post List")
    job_post_list_frame.pack(fill="both", expand="true", padx=10, pady=10)

    job_post_listbox = tk.Listbox(job_post_list_frame)
    job_post_listbox.pack(fill="both", expand="true", padx=5, pady=5)

    display_button = ttk.Button(job_post_list_frame, text="Display Job Posts", command=display_job_posts)
    display_button.pack(padx=5, pady=5)

    # Label to display success messages
    success_label = ttk.Label(app, text="", foreground="green")
    success_label.pack(padx=10, pady=10)

    # Run the application
    app.mainloop()

    # Close the database connection when the application exits
    db_connection.close()
if __name__ == "__main__":
    main()
