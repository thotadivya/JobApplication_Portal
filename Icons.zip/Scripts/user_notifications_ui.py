#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import tkinter as tk
from tkinter import ttk
import MySQLdb as mysql
def main():
    # Initialize the MySQL database connection
    db_connection = mysql.connect(
        host="127.0.0.1",
        user="root",
        passwd="root",
        db="jobApplicationPortal"
    )

    # Create a cursor to interact with the database
    db_cursor = db_connection.cursor()

    # Create the main application window
    app = tk.Tk()
    app.title("User Notifications Management")

    # Function to add a new user notification
    def add_user_notification():
        user_id = user_id_entry.get()
        notification_type = notification_type_entry.get()
        message = message_entry.get()
        timestamp = timestamp_entry.get()
        is_read = is_read_var.get()
        
        # Insert a new user notification into the User_Notifications table
        db_cursor.execute(
            "INSERT INTO User_Notifications (UserID, NotificationType, Message, Timestamp, IsRead) VALUES (%s, %s, %s, %s, %s)",
            (user_id, notification_type, message, timestamp, is_read)
        )
        db_connection.commit()
        
        success_label.config(text="User Notification added successfully!")

    # Function to display user notifications
    def display_user_notifications():
        user_notification_listbox.delete(0, tk.END)
        db_cursor.execute("SELECT NotificationID, UserID, NotificationType, Message, Timestamp, IsRead FROM User_Notifications")
        user_notifications = db_cursor.fetchall()
        for entry in user_notifications:
            user_notification_listbox.insert(tk.END, entry)

    # Create a frame for user notification information
    user_notification_frame = ttk.LabelFrame(app, text="User Notification Information")
    user_notification_frame.pack(fill="both", expand="true", padx=10, pady=10)

    user_id_label = ttk.Label(user_notification_frame, text="User ID:")
    user_id_label.grid(row=0, column=0, padx=5, pady=5)

    user_id_entry = ttk.Entry(user_notification_frame)
    user_id_entry.grid(row=0, column=1, padx=5, pady=5)

    notification_type_label = ttk.Label(user_notification_frame, text="Notification Type:")
    notification_type_label.grid(row=1, column=0, padx=5, pady=5)

    notification_type_entry = ttk.Entry(user_notification_frame)
    notification_type_entry.grid(row=1, column=1, padx=5, pady=5)

    message_label = ttk.Label(user_notification_frame, text="Message:")
    message_label.grid(row=2, column=0, padx=5, pady=5)

    message_entry = ttk.Entry(user_notification_frame)
    message_entry.grid(row=2, column=1, padx=5, pady=5)

    timestamp_label = ttk.Label(user_notification_frame, text="Timestamp:")
    timestamp_label.grid(row=3, column=0, padx=5, pady=5)

    timestamp_entry = ttk.Entry(user_notification_frame)
    timestamp_entry.grid(row=3, column=1, padx=5, pady=5)

    is_read_label = ttk.Label(user_notification_frame, text="Is Read:")
    is_read_label.grid(row=4, column=0, padx=5, pady=5)

    is_read_var = tk.BooleanVar()
    is_read_checkbutton = ttk.Checkbutton(user_notification_frame, variable=is_read_var, text="Read")
    is_read_checkbutton.grid(row=4, column=1, padx=5, pady=5)

    add_button = ttk.Button(user_notification_frame, text="Add User Notification", command=add_user_notification)
    add_button.grid(row=5, columnspan=2, padx=5, pady=5)

    # Create a frame to display user notifications
    user_notification_list_frame = ttk.LabelFrame(app, text="User Notification List")
    user_notification_list_frame.pack(fill="both", expand="true", padx=10, pady=10)

    user_notification_listbox = tk.Listbox(user_notification_list_frame)
    user_notification_listbox.pack(fill="both", expand="true", padx=5, pady=5)

    display_button = ttk.Button(user_notification_list_frame, text="Display User Notifications", command=display_user_notifications)
    display_button.pack(padx=5, pady=5)

    # Label to display success messages
    success_label = ttk.Label(app, text="", foreground="green")
    success_label.pack(padx=10, pady=10)

    # Run the application
    app.mainloop()

    # Close the database connection when the application exits
    db_connection.close()
if __name__ == "__main__":
    main()
