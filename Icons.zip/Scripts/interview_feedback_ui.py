#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import tkinter as tk
from tkinter import ttk
import MySQLdb as mysql
def main():
    # Initialize the MySQL database connection
    db_connection = mysql.connect(
        host="127.0.0.1",
        user="root",
        passwd="root",
        db="jobApplicationPortal"
    )

    # Create a cursor to interact with the database
    db_cursor = db_connection.cursor()

    # Create the main application window
    app = tk.Tk()
    app.title("Interview Feedback Management")

    # Function to add new interview feedback
    def add_interview_feedback():
        interview_id = interview_id_entry.get()
        user_id = user_id_entry.get()
        feedback_date = feedback_date_entry.get()
        feedback_text = feedback_text_entry.get()
        rating = rating_entry.get()
        
        # Insert new interview feedback into the Interview_Feedback table
        db_cursor.execute(
            "INSERT INTO Interview_Feedback (InterviewID, UserID, FeedbackDate, FeedbackText, Rating) VALUES (%s, %s, %s, %s, %s)",
            (interview_id, user_id, feedback_date, feedback_text, rating)
        )
        db_connection.commit()
        
        success_label.config(text="Interview Feedback added successfully!")

    # Function to display interview feedback
    def display_interview_feedback():
        interview_feedback_listbox.delete(0, tk.END)
        db_cursor.execute("SELECT InterviewFeedbackID, InterviewID, UserID, FeedbackDate, FeedbackText, Rating FROM Interview_Feedback")
        interview_feedback = db_cursor.fetchall()
        for entry in interview_feedback:
            interview_feedback_listbox.insert(tk.END, entry)

    # Function to delete the selected interview feedback
    def delete_interview_feedback():
        selected_item = interview_feedback_listbox.curselection()
        if selected_item:
            selected_index = selected_item[0]
            selected_data = interview_feedback_listbox.get(selected_index)
            feedback_id = selected_data[0]  # Assuming the first column is the primary key (InterviewFeedbackID)
            
            # Delete the selected interview feedback from the Interview_Feedback table
            db_cursor.execute(
                "DELETE FROM Interview_Feedback WHERE InterviewFeedbackID = %s",
                (feedback_id,)
            )
            db_connection.commit()
            
            success_label.config(text="Interview Feedback deleted successfully!")
        else:
            success_label.config(text="Please select an entry to delete.")

    # Function to edit the selected interview feedback
    def edit_interview_feedback():
        selected_item = interview_feedback_listbox.curselection()
        if selected_item:
            selected_index = selected_item[0]
            selected_data = interview_feedback_listbox.get(selected_index)
            feedback_id = selected_data[0]  # Assuming the first column is the primary key (InterviewFeedbackID)
            
            # Retrieve the existing interview feedback record from the database
            db_cursor.execute("SELECT * FROM Interview_Feedback WHERE InterviewFeedbackID = %s", (feedback_id,))
            existing_record = db_cursor.fetchone()
            
            # Update the entry fields with the existing record data
            interview_id_entry.delete(0, tk.END)
            interview_id_entry.insert(0, existing_record[1])  # Assuming InterviewID is the second column
            user_id_entry.delete(0, tk.END)
            user_id_entry.insert(0, existing_record[2])  # Assuming UserID is the third column
            feedback_date_entry.delete(0, tk.END)
            feedback_date_entry.insert(0, existing_record[3])  # Assuming FeedbackDate is the fourth column
            feedback_text_entry.delete(0, tk.END)
            feedback_text_entry.insert(0, existing_record[4])  # Assuming FeedbackText is the fifth column
            rating_entry.delete(0, tk.END)
            rating_entry.insert(0, existing_record[5])  # Assuming Rating is the sixth column
            
            success_label.config(text="Edit mode: Modify the fields and click 'Update'.")

    # Function to update the edited interview feedback
    def update_interview_feedback():
        interview_id = interview_id_entry.get()
        user_id = user_id_entry.get()
        feedback_date = feedback_date_entry.get()
        feedback_text = feedback_text_entry.get()
        rating = rating_entry.get()
        
        selected_item = interview_feedback_listbox.curselection()
        if selected_item:
            selected_index = selected_item[0]
            selected_data = interview_feedback_listbox.get(selected_index)
            feedback_id = selected_data[0]  # Assuming the first column is the primary key (InterviewFeedbackID)
            
            # Update the selected interview feedback in the Interview_Feedback table
            db_cursor.execute(
                "UPDATE Interview_Feedback SET InterviewID = %s, UserID = %s, FeedbackDate = %s, FeedbackText = %s, Rating = %s WHERE InterviewFeedbackID = %s",
                (interview_id, user_id, feedback_date, feedback_text, rating, feedback_id)
            )
            db_connection.commit()
            
            success_label.config(text="Interview Feedback updated successfully!")
        else:
            success_label.config(text="Please select an entry to edit.")

    # Create a frame for interview feedback information
    interview_feedback_frame = ttk.LabelFrame(app, text="Interview Feedback Information")
    interview_feedback_frame.pack(fill="both", expand="true", padx=10, pady=10)

    interview_id_label = ttk.Label(interview_feedback_frame, text="Interview ID:")
    interview_id_label.grid(row=0, column=0, padx=5, pady=5)

    interview_id_entry = ttk.Entry(interview_feedback_frame)
    interview_id_entry.grid(row=0, column=1, padx=5, pady=5)

    user_id_label = ttk.Label(interview_feedback_frame, text="User ID:")
    user_id_label.grid(row=1, column=0, padx=5, pady=5)

    user_id_entry = ttk.Entry(interview_feedback_frame)
    user_id_entry.grid(row=1, column=1, padx=5, pady=5)

    feedback_date_label = ttk.Label(interview_feedback_frame, text="Feedback Date:")
    feedback_date_label.grid(row=2, column=0, padx=5, pady=5)

    feedback_date_entry = ttk.Entry(interview_feedback_frame)
    feedback_date_entry.grid(row=2, column=1, padx=5, pady=5)

    feedback_text_label = ttk.Label(interview_feedback_frame, text="Feedback Text:")
    feedback_text_label.grid(row=3, column=0, padx=5, pady=5)

    feedback_text_entry = ttk.Entry(interview_feedback_frame)
    feedback_text_entry.grid(row=3, column=1, padx=5, pady=5)

    rating_label = ttk.Label(interview_feedback_frame, text="Rating:")
    rating_label.grid(row=4, column=0, padx=5, pady=5)

    rating_entry = ttk.Entry(interview_feedback_frame)
    rating_entry.grid(row=4, column=1, padx=5, pady=5)

    add_button = ttk.Button(interview_feedback_frame, text="Add Interview Feedback", command=add_interview_feedback)
    add_button.grid(row=5, columnspan=2, padx=5, pady=5)

    edit_button = ttk.Button(interview_feedback_frame, text="Edit Selected", command=edit_interview_feedback)
    edit_button.grid(row=6, columnspan=2, padx=5, pady=5)

    update_button = ttk.Button(interview_feedback_frame, text="Update", command=update_interview_feedback)
    update_button.grid(row=7, columnspan=2, padx=5, pady=5)

    delete_button = ttk.Button(interview_feedback_frame, text="Delete Selected", command=delete_interview_feedback)
    delete_button.grid(row=8, columnspan=2, padx=5, pady=5)

    # Create a frame to display interview feedback
    interview_feedback_list_frame = ttk.LabelFrame(app, text="Interview Feedback List")
    interview_feedback_list_frame.pack(fill="both", expand="true", padx=10, pady=10)

    interview_feedback_listbox = tk.Listbox(interview_feedback_list_frame)
    interview_feedback_listbox.pack(fill="both", expand="true", padx=5, pady=5)

    display_button = ttk.Button(interview_feedback_list_frame, text="Display Interview Feedback", command=display_interview_feedback)
    display_button.pack(padx=5, pady=5)

    # Label to display success messages
    success_label = ttk.Label(app, text="", foreground="green")
    success_label.pack(padx=10, pady=10)

    # Run the application
    app.mainloop()

    # Close the database connection when the application exits
    db_connection.close()
if __name__ == "__main__":
    main()
