#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import tkinter as tk
from tkinter import ttk
import MySQLdb as mysql
def main():
    # Initialize the MySQL database connection
    db_connection = mysql.connect(
        host="127.0.0.1",
        user="root",
        passwd="root",
        db="jobApplicationPortal"
    )

    # Create a cursor to interact with the database
    db_cursor = db_connection.cursor()

    # Create the main application window
    app = tk.Tk()
    app.title("Job Type Management")

    # Function to add a new job type
    def add_job_type():
        job_type_id = job_type_id_entry.get()
        type_name = type_name_entry.get()
        
        # Insert a new job type into the Job_Type table
        db_cursor.execute(
            "INSERT INTO Job_Type (JobTypeID, TypeName) VALUES (%s, %s)",
            (job_type_id, type_name,)
        )
        db_connection.commit()
        
        success_label.config(text="Job Type added successfully!")

    # Function to display job types
    def display_job_types():
        job_type_listbox.delete(0, tk.END)
        db_cursor.execute("SELECT JobTypeID, TypeName FROM Job_Type")
        job_types = db_cursor.fetchall()
        for job_type in job_types:
            job_type_listbox.insert(tk.END, job_type)

    # Create a frame for job type information
    job_type_frame = ttk.LabelFrame(app, text="Job Type Information")
    job_type_frame.pack(fill="both", expand="true", padx=10, pady=10)

    job_type_id_label = ttk.Label(job_type_frame, text="Job Type ID:")
    job_type_id_label.grid(row=0, column=0, padx=5, pady=5)

    job_type_id_entry = ttk.Entry(job_type_frame)
    job_type_id_entry.grid(row=0, column=1, padx=5, pady=5)

    type_name_label = ttk.Label(job_type_frame, text="Type Name:")
    type_name_label.grid(row=1, column=0, padx=5, pady=5)

    type_name_entry = ttk.Entry(job_type_frame)
    type_name_entry.grid(row=1, column=1, padx=5, pady=5)

    add_button = ttk.Button(job_type_frame, text="Add Job Type", command=add_job_type)
    add_button.grid(row=2, columnspan=2, padx=5, pady=5)

    # Create a frame to display job type information
    job_type_list_frame = ttk.LabelFrame(app, text="Job Type List")
    job_type_list_frame.pack(fill="both", expand="true", padx=10, pady=10)

    job_type_listbox = tk.Listbox(job_type_list_frame)
    job_type_listbox.pack(fill="both", expand="true", padx=5, pady=5)

    display_button = ttk.Button(job_type_list_frame, text="Display Job Types", command=display_job_types)
    display_button.pack(padx=5, pady=5)

    # Label to display success messages
    success_label = ttk.Label(app, text="", foreground="green")
    success_label.pack(padx=10, pady=10)

    # Run the application
    app.mainloop()

    # Close the database connection when the application exits
    db_connection.close()
if __name__ == "__main__":
    main()
