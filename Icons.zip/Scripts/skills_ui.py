#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import tkinter as tk
from tkinter import ttk
import MySQLdb as mysql
def main():
    # Initialize the MySQL database connection
    db_connection = mysql.connect(
        host="127.0.0.1",
        user="root",
        passwd="root",
        db="jobApplicationPortal"
    )

    # Create a cursor to interact with the database
    db_cursor = db_connection.cursor()

    # Create the main application window
    app = tk.Tk()
    app.title("Skills Management")

    # Function to add a new skill
    def add_skill():
        skill_name = skill_name_entry.get()
        skill_description = skill_description_entry.get()
        skill_level = skill_level_entry.get()
        
        # Insert a new skill into the Skills table
        db_cursor.execute(
            "INSERT INTO Skills (SkillName, SkillDescription, SkillLevel) VALUES (%s, %s, %s)",
            (skill_name, skill_description, skill_level)
        )
        db_connection.commit()
        
        success_label.config(text="Skill added successfully!")

    # Function to display skills
    def display_skills():
        skill_listbox.delete(0, tk.END)
        db_cursor.execute("SELECT SkillID, SkillName, SkillDescription, SkillLevel FROM Skills")
        skills = db_cursor.fetchall()
        for skill in skills:
            skill_listbox.insert(tk.END, skill)

    # Function to delete the selected skill
    def delete_skill():
        selected_item = skill_listbox.curselection()
        if selected_item:
            selected_index = selected_item[0]
            selected_data = skill_listbox.get(selected_index)
            skill_id = selected_data[0]  # Assuming the first column is the primary key (SkillID)
            
            # Delete the selected skill from the Skills table
            db_cursor.execute(
                "DELETE FROM Skills WHERE SkillID = %s",
                (skill_id,)
            )
            db_connection.commit()
            
            success_label.config(text="Skill deleted successfully!")
        else:
            success_label.config(text="Please select a skill to delete.")

    # Function to edit the selected skill
    def edit_skill():
        selected_item = skill_listbox.curselection()
        if selected_item:
            selected_index = selected_item[0]
            selected_data = skill_listbox.get(selected_index)
            skill_id = selected_data[0]  # Assuming the first column is the primary key (SkillID)
            
            # Retrieve the existing skill record from the database
            db_cursor.execute("SELECT * FROM Skills WHERE SkillID = %s", (skill_id,))
            existing_record = db_cursor.fetchone()
            
            # Update the entry fields with the existing record data
            skill_name_entry.delete(0, tk.END)
            skill_name_entry.insert(0, existing_record[1])  # Assuming SkillName is the second column
            skill_description_entry.delete(0, tk.END)
            skill_description_entry.insert(0, existing_record[2])  # Assuming SkillDescription is the third column
            skill_level_entry.delete(0, tk.END)
            skill_level_entry.insert(0, existing_record[3])  # Assuming SkillLevel is the fourth column
            
            success_label.config(text="Edit mode: Modify the fields and click 'Update'.")

    # Function to update the edited skill
    def update_skill():
        skill_name = skill_name_entry.get()
        skill_description = skill_description_entry.get()
        skill_level = skill_level_entry.get()
        
        selected_item = skill_listbox.curselection()
        if selected_item:
            selected_index = selected_item[0]
            selected_data = skill_listbox.get(selected_index)
            skill_id = selected_data[0]  # Assuming the first column is the primary key (SkillID)
            
            # Update the selected skill in the Skills table
            db_cursor.execute(
                "UPDATE Skills SET SkillName = %s, SkillDescription = %s, SkillLevel = %s WHERE SkillID = %s",
                (skill_name, skill_description, skill_level, skill_id)
            )
            db_connection.commit()
            
            success_label.config(text="Skill updated successfully!")
        else:
            success_label.config(text="Please select a skill to edit.")

    # Create a frame for skill information
    skill_frame = ttk.LabelFrame(app, text="Skill Information")
    skill_frame.pack(fill="both", expand="true", padx=10, pady=10)

    skill_name_label = ttk.Label(skill_frame, text="Skill Name:")
    skill_name_label.grid(row=0, column=0, padx=5, pady=5)

    skill_name_entry = ttk.Entry(skill_frame)
    skill_name_entry.grid(row=0, column=1, padx=5, pady=5)

    skill_description_label = ttk.Label(skill_frame, text="Skill Description:")
    skill_description_label.grid(row=1, column=0, padx=5, pady=5)

    skill_description_entry = ttk.Entry(skill_frame)
    skill_description_entry.grid(row=1, column=1, padx=5, pady=5)

    skill_level_label = ttk.Label(skill_frame, text="Skill Level:")
    skill_level_label.grid(row=2, column=0, padx=5, pady=5)

    skill_level_entry = ttk.Entry(skill_frame)
    skill_level_entry.grid(row=2, column=1, padx=5, pady=5)

    add_button = ttk.Button(skill_frame, text="Add Skill", command=add_skill)
    add_button.grid(row=3, columnspan=2, padx=5, pady=5)

    edit_button = ttk.Button(skill_frame, text="Edit Selected", command=edit_skill)
    edit_button.grid(row=4, columnspan=2, padx=5, pady=5)

    update_button = ttk.Button(skill_frame, text="Update", command=update_skill)
    update_button.grid(row=5, columnspan=2, padx=5, pady=5)

    # Create a frame to display skills
    skill_list_frame = ttk.LabelFrame(app, text="Skill List")
    skill_list_frame.pack(fill="both", expand="true", padx=10, pady=10)

    skill_listbox = tk.Listbox(skill_list_frame)
    skill_listbox.pack(fill="both", expand="true", padx=5, pady=5)

    delete_button = ttk.Button(skill_list_frame, text="Delete Selected", command=delete_skill)
    delete_button.pack(side="left", padx=5, pady=5)

    display_button = ttk.Button(skill_list_frame, text="Display Skills", command=display_skills)
    display_button.pack(side="right", padx=5, pady=5)

    # Label to display success messages
    success_label = ttk.Label(app, text="", foreground="green")
    success_label.pack(padx=10, pady=10)

    # Run the application
    app.mainloop()

    # Close the database connection when the application exits
    db_connection.close()
if __name__ == "__main__":
    main()
