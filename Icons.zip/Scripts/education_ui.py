#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import tkinter as tk
from tkinter import ttk
import MySQLdb as mysql
from tkinter import messagebox
def main():
    # Initialize the MySQL database connection
    db_connection = mysql.connect(
        host="127.0.0.1",
        user="root",
        passwd="root",
        db="jobApplicationPortal"
    )

    # Create a cursor to interact with the database
    db_cursor = db_connection.cursor()

    # Create the main application window
    app = tk.Tk()
    app.title("Education Management")

    # Function to add a new education record
    def add_education():
        education_id = education_id_entry.get()
        user_id = user_id_entry.get()
        institution = institution_entry.get()
        degree = degree_entry.get()
        
        # Insert a new education record into the Education table
        db_cursor.execute(
            "INSERT INTO Education (EducationID, UserID, Institution, Degree) VALUES (%s, %s, %s, %s)",
            (education_id, user_id, institution, degree)
        )
        db_connection.commit()
        
        success_label.config(text="Education record added successfully!")
        display_educations()

    # Function to display education records
    def display_educations():
        education_listbox.delete(0, tk.END)
        db_cursor.execute("SELECT EducationID, UserID, Institution, Degree FROM Education")
        educations = db_cursor.fetchall()
        for education in educations:
            education_listbox.insert(tk.END, education)

    # Function to edit the selected education record
    def edit_education():
        selected_item = education_listbox.curselection()
        if selected_item:
            selected_index = selected_item[0]
            selected_data = education_listbox.get(selected_index)
            education_id = selected_data[0]  # Assuming the first column is the primary key (EducationID)

            # Create a new window for editing
            edit_window = tk.Toplevel(app)
            edit_window.title("Edit Education Record")

            # Labels and Entry widgets for input
            edit_education_id_label = ttk.Label(edit_window, text="Education ID:")
            edit_education_id_label.grid(row=0, column=0, padx=5, pady=5)

            edit_education_id_entry = ttk.Entry(edit_window)
            edit_education_id_entry.grid(row=0, column=1, padx=5, pady=5)
            edit_education_id_entry.insert(0, selected_data[0])  # Pre-fill with existing Education ID

            edit_user_id_label = ttk.Label(edit_window, text="User ID:")
            edit_user_id_label.grid(row=1, column=0, padx=5, pady=5)

            edit_user_id_entry = ttk.Entry(edit_window)
            edit_user_id_entry.grid(row=1, column=1, padx=5, pady=5)
            edit_user_id_entry.insert(0, selected_data[1])  # Pre-fill with existing User ID

            edit_institution_label = ttk.Label(edit_window, text="Institution:")
            edit_institution_label.grid(row=2, column=0, padx=5, pady=5)

            edit_institution_entry = ttk.Entry(edit_window)
            edit_institution_entry.grid(row=2, column=1, padx=5, pady=5)
            edit_institution_entry.insert(0, selected_data[2])  # Pre-fill with existing Institution

            edit_degree_label = ttk.Label(edit_window, text="Degree:")
            edit_degree_label.grid(row=3, column=0, padx=5, pady=5)

            edit_degree_entry = ttk.Entry(edit_window)
            edit_degree_entry.grid(row=3, column=1, padx=5, pady=5)
            edit_degree_entry.insert(0, selected_data[3])  # Pre-fill with existing Degree

            # Function to update the education record
            def update_education():
                new_education_id = edit_education_id_entry.get()
                new_user_id = edit_user_id_entry.get()
                new_institution = edit_institution_entry.get()
                new_degree = edit_degree_entry.get()

                # Update the selected education record in the Education table
                db_cursor.execute(
                    "UPDATE Education SET EducationID = %s, UserID = %s, Institution = %s, Degree = %s WHERE EducationID = %s",
                    (new_education_id, new_user_id, new_institution, new_degree, education_id)
                )
                db_connection.commit()

                success_label.config(text="Education record updated successfully!")
                display_educations()
                edit_window.destroy()

            # Button to update the education record
            update_button = ttk.Button(edit_window, text="Update Education Record", command=update_education)
            update_button.grid(row=4, columnspan=2, padx=5, pady=5)

        else:
            messagebox.showinfo("Information", "Please select an education record to edit.")

    # Function to delete the selected education record
    def delete_education():
        selected_item = education_listbox.curselection()
        if selected_item:
            selected_index = selected_item[0]
            selected_data = education_listbox.get(selected_index)
            education_id = selected_data[0]  # Assuming the first column is the primary key (EducationID)
            
            # Delete the selected education record from the Education table
            db_cursor.execute(
                "DELETE FROM Education WHERE EducationID = %s",
                (education_id,)
            )
            db_connection.commit()
            
            success_label.config(text="Education record deleted successfully!")
            display_educations()
        else:
            messagebox.showinfo("Information", "Please select an education record to delete.")

    # Create a frame for education record information
    education_frame = ttk.LabelFrame(app, text="Education Record Information")
    education_frame.pack(fill="both", expand="true", padx=10, pady=10)

    education_id_label = ttk.Label(education_frame, text="Education ID:")
    education_id_label.grid(row=0, column=0, padx=5, pady=5)

    education_id_entry = ttk.Entry(education_frame)
    education_id_entry.grid(row=0, column=1, padx=5, pady=5)

    user_id_label = ttk.Label(education_frame, text="User ID:")
    user_id_label.grid(row=1, column=0, padx=5, pady=5)

    user_id_entry = ttk.Entry(education_frame)
    user_id_entry.grid(row=1, column=1, padx=5, pady=5)

    institution_label = ttk.Label(education_frame, text="Institution:")
    institution_label.grid(row=2, column=0, padx=5, pady=5)

    institution_entry = ttk.Entry(education_frame)
    institution_entry.grid(row=2, column=1, padx=5, pady=5)

    degree_label = ttk.Label(education_frame, text="Degree:")
    degree_label.grid(row=3, column=0, padx=5, pady=5)

    degree_entry = ttk.Entry(education_frame)
    degree_entry.grid(row=3, column=1, padx=5, pady=5)

    add_button = ttk.Button(education_frame, text="Add Education Record", command=add_education)
    add_button.grid(row=4, columnspan=2, padx=5, pady=5)

    # Create Edit and Delete Buttons
    edit_button = ttk.Button(education_frame, text="Edit Education Record", command=edit_education)
    edit_button.grid(row=5, column=0, padx=5, pady=5)

    delete_button = ttk.Button(education_frame, text="Delete Education Record", command=delete_education)
    delete_button.grid(row=5, column=1, padx=5, pady=5)

    # Create a frame to display education records
    education_list_frame = ttk.LabelFrame(app, text="Education Record List")
    education_list_frame.pack(fill="both", expand="true", padx=10, pady=10)

    education_listbox = tk.Listbox(education_list_frame)
    education_listbox.pack(fill="both", expand="true", padx=5, pady=5)

    display_button = ttk.Button(education_list_frame, text="Display Education Records", command=display_educations)
    display_button.pack(padx=5, pady=5)

    # Label to display success messages
    success_label = ttk.Label(app, text="", foreground="green")
    success_label.pack(padx=10, pady=10)

    # Run the application
    app.mainloop()

    # Close the database connection when the application exits
    db_connection.close()
if __name__ == "__main__":
    main()
