#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import tkinter as tk
from tkinter import ttk
import MySQLdb as mysql
def main():
    # Initialize the MySQL database connection
    db_connection = mysql.connect(
        host="127.0.0.1",
        user="root",
        passwd="root",
        db="jobApplicationPortal"
    )

    # Create a cursor to interact with the database
    db_cursor = db_connection.cursor()

    # Create the main application window
    app = tk.Tk()
    app.title("Admin Management")

    # Function to add a new admin
    def add_admin():
        username = username_entry.get()
        password = password_entry.get()
        
        # Insert a new admin into the Admin table
        db_cursor.execute(
            "INSERT INTO Admin (Username, Password) VALUES (%s, %s)",
            (username, password)
        )
        db_connection.commit()
        
        success_label.config(text="Admin added successfully!")

    # Function to display admins
    def display_admins():
        admin_listbox.delete(0, tk.END)
        db_cursor.execute("SELECT AdminID, Username FROM Admin")
        admins = db_cursor.fetchall()
        for admin in admins:
            admin_listbox.insert(tk.END, admin)

    # Function to delete the selected admin
    def delete_admin():
        selected_item = admin_listbox.curselection()
        if selected_item:
            selected_index = selected_item[0]
            selected_data = admin_listbox.get(selected_index)
            admin_id = selected_data[0]  # Assuming the first column is the primary key (AdminID)
            
            # Delete the selected admin from the Admin table
            db_cursor.execute(
                "DELETE FROM Admin WHERE AdminID = %s",
                (admin_id,)
            )
            db_connection.commit()
            
            success_label.config(text="Admin deleted successfully!")
        else:
            success_label.config(text="Please select an admin to delete.")

    # Function to edit the selected admin
    def edit_admin():
        selected_item = admin_listbox.curselection()
        if selected_item:
            selected_index = selected_item[0]
            selected_data = admin_listbox.get(selected_index)
            admin_id = selected_data[0]  # Assuming the first column is the primary key (AdminID)
            
            # Retrieve the existing admin record from the database
            db_cursor.execute("SELECT * FROM Admin WHERE AdminID = %s", (admin_id,))
            existing_record = db_cursor.fetchone()
            
            # Update the entry fields with the existing record data
            username_entry.delete(0, tk.END)
            username_entry.insert(0, existing_record[1])  # Assuming Username is the second column
            password_entry.delete(0, tk.END)
            password_entry.insert(0, existing_record[2])  # Assuming Password is the third column
            
            success_label.config(text="Edit mode: Modify the fields and click 'Update'.")

    # Function to update the edited admin
    def update_admin():
        username = username_entry.get()
        password = password_entry.get()
        
        selected_item = admin_listbox.curselection()
        if selected_item:
            selected_index = selected_item[0]
            selected_data = admin_listbox.get(selected_index)
            admin_id = selected_data[0]  # Assuming the first column is the primary key (AdminID)
            
            # Update the selected admin in the Admin table
            db_cursor.execute(
                "UPDATE Admin SET Username = %s, Password = %s WHERE AdminID = %s",
                (username, password, admin_id)
            )
            db_connection.commit()
            
            success_label.config(text="Admin updated successfully!")
        else:
            success_label.config(text="Please select an admin to edit.")

    # Create a frame for admin information
    admin_frame = ttk.LabelFrame(app, text="Admin Information")
    admin_frame.pack(fill="both", expand="true", padx=10, pady=10)

    username_label = ttk.Label(admin_frame, text="Username:")
    username_label.grid(row=0, column=0, padx=5, pady=5)

    username_entry = ttk.Entry(admin_frame)
    username_entry.grid(row=0, column=1, padx=5, pady=5)

    password_label = ttk.Label(admin_frame, text="Password:")
    password_label.grid(row=1, column=0, padx=5, pady=5)

    password_entry = ttk.Entry(admin_frame)
    password_entry.grid(row=1, column=1, padx=5, pady=5)

    add_button = ttk.Button(admin_frame, text="Add Admin", command=add_admin)
    add_button.grid(row=2, columnspan=2, padx=5, pady=5)

    edit_button = ttk.Button(admin_frame, text="Edit Selected", command=edit_admin)
    edit_button.grid(row=3, columnspan=2, padx=5, pady=5)

    update_button = ttk.Button(admin_frame, text="Update", command=update_admin)
    update_button.grid(row=4, columnspan=2, padx=5, pady=5)

    # Create a frame to display admins
    admin_list_frame = ttk.LabelFrame(app, text="Admin List")
    admin_list_frame.pack(fill="both", expand="true", padx=10, pady=10)

    admin_listbox = tk.Listbox(admin_list_frame)
    admin_listbox.pack(fill="both", expand="true", padx=5, pady=5)

    delete_button = ttk.Button(admin_list_frame, text="Delete Selected", command=delete_admin)
    delete_button.pack(side="left", padx=5, pady=5)

    display_button = ttk.Button(admin_list_frame, text="Display Admins", command=display_admins)
    display_button.pack(side="right", padx=5, pady=5)

    # Label to display success messages
    success_label = ttk.Label(app, text="", foreground="green")
    success_label.pack(padx=10, pady=10)

    # Run the application
    app.mainloop()

    # Close the database connection when the application exits
    db_connection.close()
if __name__ == "__main__":
    main()
