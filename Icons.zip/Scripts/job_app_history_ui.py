#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import tkinter as tk
from tkinter import ttk
import MySQLdb as mysql
def main():
    # Initialize the MySQL database connection
    db_connection = mysql.connect(
        host="127.0.0.1",
        user="root",
        passwd="root",
        db="jobApplicationPortal"
    )

    # Create a cursor to interact with the database
    db_cursor = db_connection.cursor()

    # Create the main application window
    app = tk.Tk()
    app.title("Job Application History Management")

    # Function to add a new job application history
    def add_application_history():
        user_id = user_id_entry.get()
        job_post_id = job_post_id_entry.get()
        application_date = application_date_entry.get()
        status = status_entry.get()
        notes = notes_entry.get()
        
        # Insert a new job application history into the Job_Application_History table
        db_cursor.execute(
            "INSERT INTO Job_Application_History (UserID, JobPostID, ApplicationDate, Status, Notes) VALUES (%s, %s, %s, %s, %s)",
            (user_id, job_post_id, application_date, status, notes)
        )
        db_connection.commit()
        
        success_label.config(text="Job Application History added successfully!")

    # Function to display job application history
    def display_application_history():
        application_history_listbox.delete(0, tk.END)
        db_cursor.execute("SELECT ApplicationHistoryID, UserID, JobPostID, ApplicationDate, Status, Notes FROM Job_Application_History")
        application_history = db_cursor.fetchall()
        for entry in application_history:
            application_history_listbox.insert(tk.END, entry)

    # Function to delete the selected job application history
    def delete_application_history():
        selected_item = application_history_listbox.curselection()
        if selected_item:
            selected_index = selected_item[0]
            selected_data = application_history_listbox.get(selected_index)
            history_id = selected_data[0]  # Assuming the first column is the primary key (ApplicationHistoryID)
            
            # Delete the selected job application history from the Job_Application_History table
            db_cursor.execute(
                "DELETE FROM Job_Application_History WHERE ApplicationHistoryID = %s",
                (history_id,)
            )
            db_connection.commit()
            
            success_label.config(text="Job Application History deleted successfully!")
        else:
            success_label.config(text="Please select an entry to delete.")

    # Function to edit the selected job application history
    def edit_application_history():
        selected_item = application_history_listbox.curselection()
        if selected_item:
            selected_index = selected_item[0]
            selected_data = application_history_listbox.get(selected_index)
            history_id = selected_data[0]  # Assuming the first column is the primary key (ApplicationHistoryID)
            
            # Retrieve the existing job application history record from the database
            db_cursor.execute("SELECT * FROM Job_Application_History WHERE ApplicationHistoryID = %s", (history_id,))
            existing_record = db_cursor.fetchone()
            
            # Update the entry fields with the existing record data
            user_id_entry.delete(0, tk.END)
            user_id_entry.insert(0, existing_record[1])  # Assuming UserID is the second column
            job_post_id_entry.delete(0, tk.END)
            job_post_id_entry.insert(0, existing_record[2])  # Assuming JobPostID is the third column
            application_date_entry.delete(0, tk.END)
            application_date_entry.insert(0, existing_record[3])  # Assuming ApplicationDate is the fourth column
            status_entry.delete(0, tk.END)
            status_entry.insert(0, existing_record[4])  # Assuming Status is the fifth column
            notes_entry.delete(0, tk.END)
            notes_entry.insert(0, existing_record[5])  # Assuming Notes is the sixth column
            
            success_label.config(text="Edit mode: Modify the fields and click 'Update'.")

    # Function to update the edited job application history
    def update_application_history():
        user_id = user_id_entry.get()
        job_post_id = job_post_id_entry.get()
        application_date = application_date_entry.get()
        status = status_entry.get()
        notes = notes_entry.get()
        
        selected_item = application_history_listbox.curselection()
        if selected_item:
            selected_index = selected_item[0]
            selected_data = application_history_listbox.get(selected_index)
            history_id = selected_data[0]  # Assuming the first column is the primary key (ApplicationHistoryID)
            
            # Update the selected job application history in the Job_Application_History table
            db_cursor.execute(
                "UPDATE Job_Application_History SET UserID = %s, JobPostID = %s, ApplicationDate = %s, Status = %s, Notes = %s WHERE ApplicationHistoryID = %s",
                (user_id, job_post_id, application_date, status, notes, history_id)
            )
            db_connection.commit()
            
            success_label.config(text="Job Application History updated successfully!")
        else:
            success_label.config(text="Please select an entry to update.")

    # Function to clear the entry fields
    def clear_fields():
        user_id_entry.delete(0, tk.END)
        job_post_id_entry.delete(0, tk.END)
        application_date_entry.delete(0, tk.END)
        status_entry.delete(0, tk.END)
        notes_entry.delete(0, tk.END)
        
        success_label.config(text="Fields cleared.")

    # Create a frame for job application history information
    application_history_frame = ttk.LabelFrame(app, text="Job Application History Information")
    application_history_frame.pack(fill="both", expand="true", padx=10, pady=10)

    user_id_label = ttk.Label(application_history_frame, text="User ID:")
    user_id_label.grid(row=0, column=0, padx=5, pady=5)

    user_id_entry = ttk.Entry(application_history_frame)
    user_id_entry.grid(row=0, column=1, padx=5, pady=5)

    job_post_id_label = ttk.Label(application_history_frame, text="Job Post ID:")
    job_post_id_label.grid(row=1, column=0, padx=5, pady=5)

    job_post_id_entry = ttk.Entry(application_history_frame)
    job_post_id_entry.grid(row=1, column=1, padx=5, pady=5)

    application_date_label = ttk.Label(application_history_frame, text="Application Date:")
    application_date_label.grid(row=2, column=0, padx=5, pady=5)

    application_date_entry = ttk.Entry(application_history_frame)
    application_date_entry.grid(row=2, column=1, padx=5, pady=5)

    status_label = ttk.Label(application_history_frame, text="Status:")
    status_label.grid(row=3, column=0, padx=5, pady=5)

    status_entry = ttk.Entry(application_history_frame)
    status_entry.grid(row=3, column=1, padx=5, pady=5)

    notes_label = ttk.Label(application_history_frame, text="Notes:")
    notes_label.grid(row=4, column=0, padx=5, pady=5)

    notes_entry = ttk.Entry(application_history_frame)
    notes_entry.grid(row=4, column=1, padx=5, pady=5)

    add_button = ttk.Button(application_history_frame, text="Add Application History", command=add_application_history)
    add_button.grid(row=5, columnspan=2, padx=5, pady=5)

    edit_button = ttk.Button(application_history_frame, text="Edit Selected", command=edit_application_history)
    edit_button.grid(row=6, columnspan=2, padx=5, pady=5)

    update_button = ttk.Button(application_history_frame, text="Update", command=update_application_history)
    update_button.grid(row=7, columnspan=2, padx=5, pady=5)

    delete_button = ttk.Button(application_history_frame, text="Delete Selected", command=delete_application_history)
    delete_button.grid(row=8, columnspan=2, padx=5, pady=5)

    clear_button = ttk.Button(application_history_frame, text="Clear Fields", command=clear_fields)
    clear_button.grid(row=9, columnspan=2, padx=5, pady=5)

    # Create a frame to display job application history
    application_history_list_frame = ttk.LabelFrame(app, text="Job Application History List")
    application_history_list_frame.pack(fill="both", expand="true", padx=10, pady=10)

    application_history_listbox = tk.Listbox(application_history_list_frame)
    application_history_listbox.pack(fill="both", expand="true", padx=5, pady=5)

    display_button = ttk.Button(application_history_list_frame, text="Display Application History", command=display_application_history)
    display_button.pack(padx=5, pady=5)

    # Label to display success messages
    success_label = ttk.Label(app, text="", foreground="green")
    success_label.pack(padx=10, pady=10)

    # Run the application
    app.mainloop()

    # Close the database connection when the application exits
    db_connection.close()
if __name__ == "__main__":
    main()
