#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import tkinter as tk
from tkinter import ttk
import MySQLdb as mysql
def main():
    # Initialize the MySQL database connection
    db_connection = mysql.connect(
        host="127.0.0.1",
        user="root",
        passwd="root",
        db="jobApplicationPortal"
    )

    # Create a cursor to interact with the database
    db_cursor = db_connection.cursor()

    # Create the main application window
    app = tk.Tk()
    app.title("Industry Management")

    # Function to add a new industry
    def add_industry():
        industry_id = industry_id_entry.get()
        industry_name = industry_name_entry.get()
        
        # Insert a new industry into the Industry table
        db_cursor.execute(
            "INSERT INTO Industry (IndustryID, Name) VALUES (%s, %s)",
            (industry_id, industry_name,)
        )
        db_connection.commit()
        
        success_label.config(text="Industry added successfully!")

    # Function to display industries
    def display_industries():
        industry_listbox.delete(0, tk.END)
        db_cursor.execute("SELECT IndustryID, Name FROM Industry")
        industries = db_cursor.fetchall()
        for industry in industries:
            industry_listbox.insert(tk.END, industry)

    # Create a frame for industry information
    industry_frame = ttk.LabelFrame(app, text="Industry Information")
    industry_frame.pack(fill="both", expand="true", padx=10, pady=10)

    industry_id_label = ttk.Label(industry_frame, text="Industry ID:")
    industry_id_label.grid(row=0, column=0, padx=5, pady=5)

    industry_id_entry = ttk.Entry(industry_frame)
    industry_id_entry.grid(row=0, column=1, padx=5, pady=5)

    industry_name_label = ttk.Label(industry_frame, text="Industry Name:")
    industry_name_label.grid(row=1, column=0, padx=5, pady=5)

    industry_name_entry = ttk.Entry(industry_frame)
    industry_name_entry.grid(row=1, column=1, padx=5, pady=5)

    add_button = ttk.Button(industry_frame, text="Add Industry", command=add_industry)
    add_button.grid(row=2, columnspan=2, padx=5, pady=5)

    # Create a frame to display industry information
    industry_list_frame = ttk.LabelFrame(app, text="Industry List")
    industry_list_frame.pack(fill="both", expand="true", padx=10, pady=10)

    industry_listbox = tk.Listbox(industry_list_frame)
    industry_listbox.pack(fill="both", expand="true", padx=5, pady=5)

    display_button = ttk.Button(industry_list_frame, text="Display Industries", command=display_industries)
    display_button.pack(padx=5, pady=5)

    # Label to display success messages
    success_label = ttk.Label(app, text="", foreground="green")
    success_label.pack(padx=10, pady=10)

    # Run the application
    app.mainloop()

    # Close the database connection when the application exits
    db_connection.close()
if __name__ == "__main__":
    main()
